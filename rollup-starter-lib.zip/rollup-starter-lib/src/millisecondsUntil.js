export default function millisecondsUntil(date) {
	return date - Date.now();
}